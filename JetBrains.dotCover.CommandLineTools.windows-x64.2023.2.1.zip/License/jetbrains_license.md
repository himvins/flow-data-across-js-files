JETBRAINS USER AGREEMENT
========================

**Version 1.4, effective as of September 22, 2021**

IMPORTANT! READ CAREFULLY:

THIS IS A LEGAL AGREEMENT. BY CLICKING ON THE “I AGREE” (OR SIMILAR)
BUTTON THAT IS PRESENTED TO YOU AT THE TIME OF YOUR FIRST USE OF THE
JETBRAINS SOFTWARE, SUPPORT, OR PRODUCTS, YOU BECOME A PARTY TO THIS
AGREEMENT, YOU DECLARE YOU HAVE THE LEGAL CAPACITY TO ENTER INTO SUCH
AGREEMENT, AND YOU CONSENT TO BE BOUND BY ALL THE TERMS AND CONDITIONS
SET FORTH BELOW.

1. PARTIES
----------

1.1. “JetBrains” or “we” means JetBrains s.r.o., having its principal
place of business at Na Hrebenech II 1718/10, Prague, 14000, Czech
Republic, registered in the Commercial Register maintained by the
Municipal Court of Prague, Section C, File 86211, ID. No.: 265 02 275.

1.2. “Product Holder” means the sole proprietor or legal entity
specified in the Subscription Confirmation. For legal entities, “Product
Holder” includes any entity which controls, is controlled by, or is
under common control with Product Holder. For the purposes of this
definition, “control” means (i) the power, directly or indirectly, to
direct or manage such entity, whether by contract or otherwise, or (ii)
ownership of fifty percent (50%) or more of the outstanding shares or
beneficial ownership of such entity.

1.3. “User” or “you” means the individual given the right to use a
Product in accordance with this Agreement. For the avoidance of doubt,
User is a natural person and not a corporation, company, partnership or
association, or other entity or organization.

2. DEFINITIONS
--------------

2.1. “Affiliate” means, with respect to any party, any entity that
directly, or indirectly through one or more intermediaries, controls, is
controlled by, or is under common control of such party; “control” for
such purposes means the possession, direct or indirect, of the power to
direct or affect the direction of the management and policies of a
person or entity, whether through the ownership of voting securities, by
contract, or otherwise.

2.2. “Agreement” means this JetBrains User Agreement covering use of the
Product by individual Users.

2.3. “Bug Fix Update” for a particular Product Version means a software
update or release that is specifically identified by JetBrains as a bug
fix for that Product Version.

2.4. “Fallback Date” means the date 12 months prior to the expiration
date of the Subscription.

2.5. “Fallback Version” means the most recent Product Version that
JetBrains made available for public purchase prior to the Fallback Date,
along with any Bug Fix Updates for that Product Version. The Fallback
Version does not include any Product updates or upgrades other than Bug
Fix Updates that User may have used in the period between the Fallback
Date and the expiration date of User’s Subscription. For more
information, see our FAQ available at
<https://sales.jetbrains.com/hc/en-gb>.

2.6. “JetBrains Account” or “JBA” means an account at
<https://account.jetbrains.com> created by User, having a unique name
and password, and enabling User to manage Subscription administration
and/or access Products.

2.7. “JetBrains Website” means any website that is the property of
JetBrains, including but not limited to everything hosted under the
top-level domains <span
style="text-decoration:underline;">jetbrains.com</span>, <span
style="text-decoration:underline;">jetbrains.net</span>, <span
style="text-decoration:underline;">jetbrains.org</span>, <span
style="text-decoration:underline;">jetbrains.ru</span>, <span
style="text-decoration:underline;">jetbrains.team</span>, <span
style="text-decoration:underline;">intellij.net</span>, <span
style="text-decoration:underline;">kotl.in</span>, and <span
style="text-decoration:underline;">kotlinlang.org</span>.

2.8. “Machine” means a computing device used by a User for running the
Product.

2.9. “Personal Data” means any information relating to an identified or
identifiable natural person.

2.10. “Privacy Policy” means the JetBrains Privacy Policy available at
<https://www.jetbrains.com/legal/docs/privacy/privacy.html>, which may
be updated from time to time.

2.11. “Product” means any generally available JetBrains software
intended for mass distribution which may be designated by JetBrains as
part of the JetBrains Toolbox on the JetBrains Website. “Product” does
not include JetBrains ‘Team Tools’ software and services such as Space,
Code With Me, YouTrack, TeamCity, Upsource, Datalore, Hub, or any other
software, services, or products that are, in JetBrains’ sole discretion,
subject to different terms and conditions. JetBrains does not develop
Products according to Customer’s specifications, nor are Products
customized through modification or personalization.

2.12. “Product Version” means a release, update, or upgrade of a
particular Product that is not identified by JetBrains as being made for
the purpose of fixing software bugs.

2.13. “Redistributable Product” means an independent module of a Product
or a standalone JetBrains development tool designated by JetBrains as
“Redistributable” in its name or in its official description, such as a
Software Development Kit (SDK), Application Programming Interface (API),
or Command Line Tool application (CLT), and which may be subject to
additional terms.

2.14. “Subscription” specifies the subscription term, Products provided
to Customer, subscription fees, and payment schedules. Subscriptions do
not apply to Redistributable Products.

2.15. “Subscription Confirmation” means an email confirming Product
Holder’s rights to access and use Products (excluding Redistributable
Products), including Subscription plans, and stating the applicable use
limitations for the Product (such as, for example, the number of Users
and the license period).

3. GRANT OF RIGHTS
------------------

3.1. The Product is provided to Product Holder on a ‘per user’ basis,
where Product Holder must assign a Subscription to a specific User who
may deploy the Product on multiple Machines in accordance with the
Product documentation. If the Product is accessed via a Floating License
Server (as described in Section 6.3), the Product is provided to User on
a ‘per machine’ basis, where the Floating License Server allocates the
Subscription to a specific Machine that can only be used by one User at
a time. If Product Holder and User comply with the terms of this
Agreement, JetBrains grants to Product Holder and User the rights set
out in this Section 3 to the extent necessary to enable Product Holder
and User to effectively use the Product. All other rights remain
reserved by JetBrains.

3.2. Unless the Subscription has expired or this Agreement is terminated
in accordance with Section 13, and subject to the terms and conditions
specified in this Agreement, JetBrains grants you the non-exclusive and
non-transferable right to use each Product covered by the Subscription
as stipulated below:

(A) You may:

(i) install and use any version of the Product covered by the
Subscription on any operating system supported by the Product; and

(ii) make one copy of the Product solely for archival, security, and/or
backup purposes.

(B) You may not:

(i) allow the same Subscription to be used concurrently by more than one
(1) User, unless the Product is provided to Product Holder via a
Floating License Server as specified in Section 6.3(C);

(ii) rent, lease, reproduce, modify, adapt, create derivative works of,
distribute, sell, or transfer the Product;

(iii) provide a third party with access to the Product or your JetBrains
Account, or the right to use the Product;

(iv) reverse-engineer, decompile, disassemble, modify, translate, or
make any attempt to discover the source code of, the Product; or

(v) remove or obscure any proprietary or other notices contained in the
Product.

3.3. Section 3.2 also applies to Products not covered by the
Subscription, with the exception of 3.2(B)(i); provided, that for
Products governed by their own specific agreements or terms of use,
those shall take precedence over this Agreement to the extent of any
conflict or discrepancy.

3.4. Following the expiration of this Agreement, you may be granted
access to the Fallback Version of a Product covered by the Subscription
of the Product Holder. In that case, the rights stipulated in Section
3.1(A) shall continue on a perpetual, royalty-free, non-exclusive, and
non-transferable basis for the continued use of a Fallback Version of
each Product covered by the Subscription. The limitations set forth in
Section 3.1(B) of this Agreement apply to the usage of the Fallback
Version, as does Section 13.5. The rights granted in this Section 3.4
are expressly contingent upon User not being in breach of this
Agreement.

3.5. JetBrains has and retains all rights, title, and interest,
including all intellectual property rights, in and to the Products, any
and all related or underlying technology, and any modifications or
derivative works of the Products, including without limitation as they
may incorporate Feedback (as defined below).

3.6. If an independent module of the Product or the Product as a whole
is a Redistributable Product, the following provisions shall apply in
addition to Sections 3.1-3.5:

(A) You may:

(i) use the Redistributable Product without quantitative restrictions
unless specified otherwise in the terms relating to the use of the
particular Redistributable Product;

(ii) transfer, reproduce, redistribute, and provide access to the
Redistributable Product to a third party;

(iii) sell your product containing or using the Redistributable Product
to a third party, but not the Redistributable Product on its own;

(iv) redistribute the Redistributable Product onto another Machine for
legitimate purposes in accordance with this Agreement and applicable
law, and use the Redistributable Product on that Machine, provided that
you have received authorization from the owner of that Machine to deploy
and use the Redistributable Product in this way. You will indemnify
JetBrains against any losses, costs, or damages arising from your
deployment of the Redistributable Product onto another Machine in
violation of this Section.

(B) You agree that any Redistributable Product you reproduce,
redistribute, or provide a third party access to must be governed by an
agreement concluded between the relevant third party as a User and
JetBrains and that the third party must be bound by that agreement prior
to the use of the reproduced or redistributed Redistributable Product.
JetBrains is the exclusive owner and licensor of the Redistributable
Product. You acknowledge that you are liable to JetBrains for any loss
or damages in connection with any breach of this Section.

4. DECOMPILING RESTRICTIONS
---------------------------

Some of the Products may include decompiling functionality that enables
reproducing source code from the original binary code. You acknowledge
that binary code and source code may be protected by copyright and
trademark laws. Before using such Products for decompilation purposes,
you hereby agree to make sure that decompilation of binary code is not
prohibited by the applicable license agreement or that you have obtained
permission to decompile the binary code from the copyright owner. Using
the Products is entirely optional. JetBrains neither encourages nor
condones the use of the Products for decompiling purposes, and disclaims
any liability for their use by User in violation of applicable laws.

5. RELATED TERMS
----------------

Due to the nature of the Products provided, usage of the Products is
governed by this Agreement, the [JetBrains Website Terms of
Use](https://www.jetbrains.com/legal/docs/company/useterms.html)
available at
<https://www.jetbrains.com/legal/docs/company/useterms.html>, and the
[Purchase Terms](https://www.jetbrains.com/legal/docs/store/terms/)
available at
[https://www.jetbrains.com/legal/docs/store/terms](https://www.jetbrains.com/legal/docs/store/terms/).

6. ACCESS TO PRODUCTS
---------------------

6.1. All deliveries under this Agreement will be electronic. Product
Holder and User must have an Internet connection in order to access
their JetBrains Account and receive any deliveries. Product Holder and
User are responsible for downloading and installing the Products, which
are made available for download on the JetBrains Website.

6.2. Product Holder and User may use the JBA in accordance with the
JetBrains Account Agreement available at
<https://www.jetbrains.com/legal/docs/agreements/jetbrains_account.html>.
Product Holder and User are jointly responsible for the accuracy of any
information provided via, and any action taken through, the JBA.

6.3. Product Holder may enable User to activate and access Product in
one of the following ways:

(A) JetBrains Account – by sending an invitation from Product Holder’s
JBA to a User’s JBA. Product Holder and User acknowledge and agree that
the Product will periodically connect from the User’s Machine to
JetBrains’ servers via the Internet to confirm the User’s right to use
the Product;

(B) Activation code – by generating an offline activation code in
Product Holder’s JBA and providing it to a User for offline Product
activation. Product Holder must generate a new activation code and apply
it to the Product registration interface when prompted;

(C) License server – via an application provided by JetBrains through a
‘floating license server’ that enables Product Holder to access the
Product on a ‘per machine’ basis (“Floating License Server”). The
Floating License Server is an option that is provided at the sole
discretion of JetBrains upon written request and may be subject to
separate terms and conditions.

7. PERSONAL DATA
----------------

7.1. In connection with your use of Product(s), we and our associated
companies will process Personal Data of you as a User and the Product
Holder (if appropriate), in particular, your contact and identification
details, data about usage of our software and services, and information
about your subscription and payments, for the following purposes:

7.1.1. To provide you with software, services or information;

7.1.2. To protect us from piracy and unlawful use of our software or
services;

7.1.3. To improve our offerings based on usage;

7.1.4. For our internal records and to protect our rights and interests
and those of other users;

7.1.5. To promote and market our software and services; and

7.1.6. To fulfil legal duties stipulated by accounting, taxation, and
other laws.

You may object to the processing of your Personal Data for the purposes
of 7.1.2 through 7.1.5 at any time. More detailed information about
Personal Data processing for the above mentioned purposes and about your
rights can be found in the Privacy Policy.

7.2. For the above purposes, JetBrains may collect, among other things,
your IP address, JetBrains Account username, JetBrains Account password,
first name, last name, email address, and subscription information.

7.3. On installation and execution, the Product may send JetBrains
certain information, which will not contain any Personal Data, including
Product version, Product edition, and information about the operating
system and/or environment where the Product is installed, applicable to
tools such as ReSharper™, which is a plugin to Visual Studio™. A unique
ID, which does not contain any Personal Data, is also used to
distinguish instances. The Product can also check for available updates,
as well as available updates for plugins or components. In addition, it
can check for subscription validation, by either using the subscription
key or your JetBrains Account details. Some Products can also use
subscription information to inform you of the availability of applicable
updates.

7.4. If you opt in to anonymous data collection through the Product, the
Product may electronically send anonymous information to JetBrains
related to your usage of the Product features. This information may
include, but is not limited to, frameworks, file templates being used in
the IDEs, actions invoked, and other interactions with Product features.
This information will contain neither source code nor your Personal
Data, nor information about your JetBrains Account or subscription
information.

7.5. JetBrains is not responsible for any processing of Personal Data
accidentally sent to JetBrains by the User.

7.6. You shall keep your Personal Data up-to-date, update the
information, or if any inconsistencies arise report such inconsistencies
to JetBrains.

8. FEEDBACK
-----------

You have no obligation to provide us with ideas, suggestions, or
proposals (“Feedback”). However, if you submit Feedback to us, then you
grant us a non-exclusive, worldwide, royalty-free license that is
sub-licensable and transferable, to make, use, sell, have made, offer to
sell, import, reproduce, publicly display, distribute, modify, or
publicly perform the Feedback in any manner without any obligation,
royalty, or restriction based on intellectual property rights or
otherwise.

9. THIRD-PARTY SOFTWARE
-----------------------

The Products include code and libraries licensed to us by third parties,
including open source software (“Third-Party Software”). A list of
Third-Party Software included in each Product is available in the
respective Product documentation and/or at
<https://www.jetbrains.com/legal/third-party-software>. All Third-Party
Software is provided to Product Holder and User under the respective
terms stipulated in the Product documentation.

10. SUBSCRIPTION TRIAL
----------------------

10.1. Subject to the terms of this Agreement, User is granted a one-time
right to install and use each major version of a Product covered by the
Subscription for evaluation purposes, without charge, for a period of
thirty (30) days (or such other period as may be specified in the
official Product documentation) from the date of Product installation
(“Evaluation Period”). User’s use of the Product during the Evaluation
Period shall be limited to internal evaluation and testing of the
Product for the sole purpose of determining whether the Product meets
User’s requirements and whether User wishes to continue using the
Product.

10.2. User may end the Evaluation Period at User’s sole discretion any
time. Upon the expiration of the Evaluation Period, User’s right to
continue using the Product will terminate, unless User purchases a
Subscription to the Product. Each Product contains a feature that will
automatically disable the Product upon the expiration of the Evaluation
Period.

10.3. The limitations contained in this Section 10 do not apply to the
use of Redistributable Products, which may be used for the term of this
Agreement.

11. WARRANTY LIMITATIONS
------------------------

11.1. ALL PRODUCTS ARE PROVIDED TO YOU ON AN “AS IS” AND “AS AVAILABLE”
BASIS. USE OF THE PRODUCTS IS AT YOUR OWN RISK.

11.2. JETBRAINS MAKES NO WARRANTY AS TO THE PRODUCTS’ USE OR
PERFORMANCE. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW,
JETBRAINS (AND ITS AFFILIATES, SHAREHOLDERS, AGENTS, DIRECTORS, AND
EMPLOYEES), ITS LICENSORS, SUPPLIERS (INCLUDING THE PROVIDERS OF THIRD
PARTY SOFTWARE), AND RESELLERS (COLLECTIVELY HEREUNDER, “JETBRAINS
PARTIES”) DISCLAIM ALL WARRANTIES AND CONDITIONS, WHETHER EXPRESS OR
IMPLIED (INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT) WITH REGARD TO THE PRODUCTS AND THE PROVISION OF OR
FAILURE TO PROVIDE SUPPORT SERVICES.

11.3. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, JETBRAINS
PARTIES DO NOT REPRESENT OR WARRANT THAT THE PRODUCTS: (A) ARE ACCURATE,
RELIABLE, OR CORRECT; (B) WILL MEET YOUR REQUIREMENTS; (C) WILL BE
AVAILABLE AT ANY PARTICULAR TIME OR LOCATION, UNINTERRUPTED, OR SECURE;
(D) ARE FREE OF DEFECTS OR ERRORS AND THAT ANY, IF FOUND, WILL BE
CORRECTED; AND/OR (E) ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS.

11.4. ANY CONTENT OR DATA DOWNLOADED OR OTHERWISE OBTAINED THROUGH THE
USE OF THE PRODUCTS ARE DOWNLOADED AT YOUR OWN RISK; YOU AGREE YOU ARE
SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR PROPERTY AND/OR LOSS OF DATA
THAT RESULTS FROM SUCH DOWNLOAD.

11.5. YOU MAY HAVE OTHER RIGHTS, WHICH MAY NOT BE LIMITED OR EXCLUDED
AND WHICH MAY VARY FROM JURISDICTION TO JURISDICTION. THIS DOCUMENT IS
NOT INTENDED TO NEGATIVELY AFFECT SUCH RIGHTS.

12. DISCLAIMER OF DAMAGES
-------------------------

12.1. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT
WILL JETBRAINS PARTIES BE LIABLE TO YOU, YOUR AFFILIATES, USERS, OR
ANYONE ELSE FOR: (A) ANY LOSS OF USE, DATA, GOODWILL, OR PROFITS,
WHETHER OR NOT FORESEEABLE; (B) ANY LOSS OR DAMAGES IN CONNECTION WITH
TERMINATION OR SUSPENSION OF YOUR ACCESS TO THE PRODUCTS IN ACCORDANCE
WITH THIS AGREEMENT; OR (C) ANY SPECIAL, INCIDENTAL, INDIRECT,
CONSEQUENTIAL, EXEMPLARY, OR PUNITIVE DAMAGES WHATSOEVER (EVEN IF THE
RELEVANT JETBRAINS PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF THESE
DAMAGES), INCLUDING THOSE (X) RESULTING FROM LOSS OF USE, DATA, OR
PROFITS, WHETHER OR NOT THEY ARE FORESEEABLE, (Y) BASED ON ANY THEORY OF
LIABILITY, INCLUDING BREACH OF CONTRACT OR WARRANTY, STRICT LIABILITY,
NEGLIGENCE, OR OTHER TORTIOUS ACTION, OR (Z) ARISING FROM ANY OTHER
CLAIM ARISING OUT OF OR IN CONNECTION WITH YOUR USE OF OR ACCESS TO THE
PRODUCTS OR SUPPORT. THIS LIMITATION OF LIABILITY SHALL APPLY TO THE
FULLEST EXTENT PERMITTED BY LAW IN THE APPLICABLE JURISDICTION.

12.2. THE TOTAL LIABILITY OF THE JETBRAINS PARTIES IN ANY MATTER ARISING
OUT OF OR IN RELATION TO THIS AGREEMENT IS LIMITED TO THE GREATER OF (A)
TEN (10) US DOLLARS OR (B) THE AGGREGATE AMOUNT PAID OR PAYABLE BY
PRODUCT HOLDER OR USER DURING THE THREE-MONTH PERIOD PRECEDING THE
EVENT, FOR THE PRODUCTS GIVING RISE TO THE LIABILITY. THIS LIMITATION
WILL APPLY EVEN IF THE JETBRAINS PARTIES HAVE BEEN ADVISED OF THE
POSSIBILITY OF LIABILITY EXCEEDING SUCH AN AMOUNT AND NOTWITHSTANDING
ANY FAILURE OF THE ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.

13. TERM AND TERMINATION
------------------------

13.1. The term of this Agreement will commence upon acceptance of this
Agreement by User as set forth in the preamble above, and it will
continue for each Product covered by a Subscription through the end of
the applicable Subscription period specified in the respective
Subscription Confirmation, or until terminated for Products not covered
by a Subscription (unless specified otherwise by specific terms
governing the use of such Product).

13.2. You may terminate this Agreement at any time via your JetBrains
Account. If such termination occurs during a Subscription period, this
Agreement will continue to be effective until the end of that
Subscription period. In the case of Redistributable Products or Products
not covered by a Subscription, User may terminate this Agreement with
immediate effect by notifying JetBrains of such termination,
discontinuing use of such Products and deleting all copies of such
Products from its Machines and archives (notwithstanding anything else
in this Agreement).

13.3. JetBrains may terminate this Agreement and the associated
Subscription if:

(A) User has materially breached this Agreement and fails to remedy the
breach within thirty (30) days of written notice;

(B) JetBrains is required to do so by law (for example, where the
provision of the Product to User is, or becomes, unlawful); or

(C) JetBrains elects to discontinue providing the Product, in whole or
in part.

13.4. JetBrains will make reasonable efforts to notify User via email
(to the email address of the billing or technical contact provided by
User or Product Holder) as follows:

(A) Thirty (30) days prior to termination of the Agreement in the event
specified in Section 13.3(C);

(B) Three (3) days prior to termination of the Agreement in the event
specified in Section 13.3(B).

13.5. Survival. Upon the expiration or termination of this Agreement,
Sections 8, 9, 11, 12, and 16 of this Agreement survive. Upon the
expiration or termination of this Agreement by User under Section 13.2,
if User elects to use a Fallback Version in accordance with Section
3.4., these Sections will also survive with respect to the Fallback
Version, in addition to Section 3.4.

14. TEMPORARY SUSPENSION
------------------------

14.1. JetBrains reserves the right to suspend User’s access to JetBrains
Products if:

(A) Product Holder fails to pay Subscription fees on time;

(B) Product Holder’s or User’s use of Product is in violation of this
Agreement or disrupts or imminently threatens the security, integrity,
or availability of a Product.

14.2. If JetBrains suspends User’s access to Products for non-payment in
accordance with Section 14.1(A), Product Holder must pay all past due
amounts in order to resume access to Product.

15. EXPORT REGULATIONS
----------------------

15.1. User must comply with all applicable laws and regulations with
regard to economic sanctions, export controls, import regulations,
restrictive measures, and trade embargoes (all herein referred to as
“Sanctions”), including those of the European Union and United States.
User declares and warrants that it is not a person targeted by
Sanctions, nor is it otherwise owned or controlled by or acting on
behalf of any entity or person targeted by Sanctions. User agrees that
it will not download or otherwise export or re-export the Product or any
related technical data directly or indirectly to any person targeted by
Sanctions or download or otherwise use the Product for any end-use
prohibited or restricted by Sanctions.

15.2. User must immediately report any concerns of non-compliance
regarding Sanctions to <compliance@jetbrains.com>,
<legal@jetbrains.com>, or <ethics@jetbrains.com>, and cooperate with
JetBrains in its efforts to verify and ensure compliance with Sanctions.

16. GENERAL
-----------

16.1. **Entire Agreement**. The following documents are part of
(‘incorporated into’) this Agreement: the JetBrains Privacy Policy,
available at
<https://www.jetbrains.com/legal/docs/privacy/privacy.html>, the Data
Processing Addendum (if applicable) at
<https://www.jetbrains.com/legal/dpa>, and the JetBrains Terms and
Conditions of Purchase, available at
<https://www.jetbrains.com/legal/docs/store/terms>. Together, these
documents form the entire agreement and replace any previous agreement
between you and us in relation to its subject matter. Except as
expressly mentioned, this Agreement does not apply or give rights to
anyone else (‘no third-party beneficiaries’). No purchase order, Product
Holder terms, or other document that purports to modify or supplement
this Agreement will vary the terms of this Agreement unless signed by
User and JetBrains.

16.2. **Reservation of Rights**. JetBrains reserves the right at any
time to cease its support of the Product and to alter prices, features,
specifications, capabilities, functions, terms of use, release dates,
general availability, and other characteristics of the Product. Nothing
in this Agreement limits any rights a consumer may have under applicable
consumer protection laws.

16.3. **Changes to this Agreement**. The Agreement can be updated from
time to time to reflect changes in the Product and how it is offered to
you.

(A) If this happens, we will update the terms on the JetBrains Website
and let you know either:

(i) by displaying them to you in the Product;

(ii) in your JetBrains Account; or

(iii) by sending the updated version to the email address used in your
JetBrains Account.

(B) Any updated Agreement will start (‘be effective’) on the date
specified in the updated Agreement. By continuing to use the Product
after the effective date, you agree to be bound by the modified
Agreement.

(C) We respect that you may not agree to the updated Agreement. If that
is the case, you can terminate your Subscription any time up to 30 days
after the effective date of the updated Agreement. Termination according
to this Section entitles you to a pro-rata refund of the pre-paid unused
Subscription fees.

(D) If you are using a Fallback Version and object to the update to the
Agreement, you can continue using the Fallback Version under the
previously applicable terms.

16.4. **Opportunity to Review**. Customer declares that it has had
sufficient opportunity to review this Agreement, understand the content
of all of its sections, negotiate its terms, and seek independent
professional legal advice before entering into it. Consequently, any
statutory “form contract” (“adhesion contract”) regulations shall not be
applicable to this Agreement.

16.5. **Severability**. If a particular term of this Agreement is not
enforceable, the unenforceability of that term will not affect any other
terms of this Agreement.

16.6. **Interpretation**. Headings and titles are for convenience only
and do not affect the interpretation of this Agreement. Terms such as
“including” are not exhaustive.

16.7. **No Waiver**. Our failure to enforce or exercise any part of this
Agreement is not a waiver of that section.

16.8. **Notice**. JetBrains may deliver any notice to User via
electronic mail to an email address provided by User, or via User’s
JetBrains Account, registered mail, personal delivery, or reputable
express courier (such as DHL, FedEx, or UPS). Any such notice will be
deemed to be effective (i) on the day the notice is sent to User via
email, (ii) upon being uploaded to User’s JetBrains Account
(irrespective of when User actually receives it), (iii) upon personal
delivery, (iv) one (1) day after deposit with an express courier, or (v)
five (5) days after deposit in the mail, whichever occurs first.

16.9. **Governing Law**. This Agreement is governed by the laws of the
Czech Republic, without reference to conflict of laws principles and
specifically excluding the United Nations Convention on Contracts for
the International Sale of Goods. The Parties to the agreement
constituted by this Agreement undertake to use best commercial efforts
to amicably settle any disputes arising hereunder (“Dispute”).

16.10. **Dispute Resolution**. Should the parties to this Agreement fail
to settle a Dispute amicably, the Dispute will be excluded from the
jurisdiction of general courts and the Dispute will be finally decided
by the Arbitration Court attached to the Czech Chamber of Commerce and
the Agricultural Chamber of the Czech Republic, by three arbitrators in
accordance with the Rules of that Arbitration Court, and the language of
the proceedings will be English; if you are a consumer, we both agree
that any Dispute-related litigation may only be brought in, and shall be
subject to the jurisdiction of, any competent court of the Czech
Republic, unless provided otherwise by applicable consumer law. Consumer
Disputes can also be settled out of court through the Czech Trade
Inspection Authority ([www.coi.cz](www.coi.cz)) or the European
Commission’s online platform for dispute resolution
(<http://ec.europa.eu/consumers/odr>).

16.11. **Data Privacy**. By accepting this Agreement, User acknowledges
that JetBrains will process personal data in accordance with JetBrains’
Privacy Policy (available at
<https://www.jetbrains.com/company/privacy.html>). Unless you have
signed an individual data processing addendum with JetBrains, the
JetBrains data processing addendum available at
<https://www.jetbrains.com/legal/dpa> applies.

16.12. **Force Majeure**. Neither party to this Agreement shall be in
breach of this Agreement, or otherwise liable to the other, by reason of
any delay in performance, or non-performance, of any of its obligations
under this Agreement (except payment obligations), arising directly from
an act of God, fire, flood, natural disaster, act of terrorism, strike,
lock-out, labor dispute, public health emergency, civil commotion, riot,
or act of war.

16.13. **Children and minors**. If you are under 18 years old, then by
entering into this Agreement you explicitly stipulate that (i) you have
legal capacity to conclude this Agreement or that you have valid consent
from a parent or legal guardian to do so and (ii) you understand the
[JetBrains Privacy
Policy](https://www.jetbrains.com/legal/docs/privacy/privacy.html). You
may not enter into this Agreement if you are under 13 years old. IF YOU
DO NOT UNDERSTAND THIS SECTION, DO NOT UNDERSTAND THE JETBRAINS PRIVACY
POLICY, OR DO NOT KNOW WHETHER YOU HAVE THE LEGAL CAPACITY TO ACCEPT
THESE TERMS, PLEASE ASK YOUR PARENT OR LEGAL GUARDIAN FOR HELP.

For further information, please contact us at <legal@jetbrains.com>.
